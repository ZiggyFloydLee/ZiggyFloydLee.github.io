/**
 * Class to model the Real Estate company data and operations
 */
import java.util.ArrayList;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class RentalManager{
    private ArrayList<Building> buildings;
    private HashMap<String, Tenant> tenants;

    public RentalManager(String buildingFile, String tenantFile){
        tenants = new HashMap<>();
        buildings = new ArrayList<>();
        readTenants(tenantFile);
        readBuildings(buildingFile);
    }
    /**
     * Method to update the array list buildings
     * @param filename where the building information is
     */
    private void readBuildings(String filename){
        File f = new File(filename);
        
        try{
            Scanner s = new Scanner(f);
            while(s.hasNextLine()){
                String [] address = s.nextLine().split(" ");
                String name = address[0];
                String add = address[2] + " " + address[3] + " " + address[4]; 
                Building bld = new Building(name, add);
                int size = Integer.parseInt(address[1]);
                for(int i = 0; i < size; i++){
                    String [] temp = s.nextLine().split(" ");
                    String number = temp[0];
                    int rooms = Integer.parseInt(temp[1]);
                    double rent = Double.parseDouble(temp[2]);
                    bld.addApartment(number, rooms, rent);
                    aptIsRented(name, number);
                }
                buildings.add(bld);
                System.out.println("Building added" + bld.getAddress().toString());
                
            }
            s.close(); 
        }catch(FileNotFoundException e){
            System.out.println();
        }
        
    }

    private boolean aptIsRented(String building, String apt){
        ArrayList<Tenant> list = tenants.values();
        for(Tenant t: list){
            if (t.getbuildingName().equals(building) && t.getAptNumber().equals(apt)){
                return true;
            }
        }
        return false;
    }
    private void readTenants(String filename){
        File file = new File(filename);
        try{
            Scanner readFile = new Scanner(file);
            while (readFile.hasNext()){
                String fname = readFile.next();
                String lname = readFile.next();
                String phone = readFile.next();
                String email = readFile.next();
                String building = readFile.next();
                String apt = readFile.next();
                String name = fname + " " + lname;
                Tenant t = new Tenant(name, phone, email, building, apt);
                tenants.put(name, t);
            }
            readFile.close();
        }
        catch(FileNotFoundException e){
            System.out.println("File not found.");
            System.exit(0);
        }
    }
    public Building findBuilding(String buildingName){
        for(int j=0; j<buildings.size(); j++){
            if(buildings.get(j).getName().equals(buildingName)){
                return buildings.get(j);
            }
        }
        return null;
    }
    public Tenant findTenant(String name){
        return tenants.get(name);
    }
    public void viewApartments(String number){
        for(int i=0; i<buildings.size(); i++){
            Apartment apt = buildings.get(i).findApartment(number);
            if(apt != null){
                System.out.println(buildings.get(i).getName() + apt);
            }
        }
    }
    /**
     * Method to display all the apartments with rent below a given amount
     * @param rent the amount
     */
    public void filterApartments(double rent){
        System.out.printf("%-15s\t%-15s\t%-15s\t%-15s\n","Apartment","Rooms","Rent","Rented/Free");
        ArrayList<Apartment> filteredApts = new ArrayList<>();
        ArrayList<Tenant> t = tenants.values();

        for(int i = 0; i < buildings.size(); i++){
            ArrayList<Apartment> apt = buildings.get(i).filterApartments(rent);
            for(int j =0; j < apt.size(); j++){
                for(int k = 0; k < t.size(); k++){
                    if(t.get(k).getAptNumber().equals(apt.get(j).getNumber())){
                        apt.get(j).rent();
                    }
                }
                filteredApts.add(apt.get(j));
            }  
        }

        bubbleSort(filteredApts);

        for(int i = 0; i < filteredApts.size(); i++){
            System.out.println(filteredApts.get(i).toString());
        }
    }
    /**
     * Bubble sort method to be used by filterApartments
     */ 
    private <E extends Comparable<E>> void bubbleSort(ArrayList<E> list) { 
        boolean sorted = false; 
        for (int k=1; k < list.size() && !sorted; k++) { 
            sorted = true; 
            for (int i=0; i<list.size()-k; i++) { 
                if (list.get(i).compareTo(list.get(i+1)) > 0) { 
                    E temp = list.get(i); 
                    list.set(i, list.get(i+1)); 
                    list.set(i+1, temp); 
                    sorted = false; 
                } 
            } 
        }
    }
    /**
     * Method to display the list of tenants and the apartments they are renting
     * See the sample output for the type of information that is displayed for eah tenant
     */
    public void viewApartmentTenants(){
        System.out.printf("%-20s\t%-10s\t%-10s\t%-5s\t%-5s\n","Tenant","Building","Apartment","Rooms","Rent");
        ArrayList<Tenant> values = tenants.values(); 
        for(int i = 0; i < values.size(); i++){
            Tenant t = values.get(i);
            Apartment a = new Apartment(null, i, i);
            for(Building b: buildings){
                if(b.getName().equals(t.getbuildingName())){
                    a = b.findApartment(t.getAptNumber());
                }
            }
            System.out.printf("%-20s\t%-10s\t%-10s\t%-5s\t%-5s\n", values.get(i).getName(), 
                                                                            values.get(i).getbuildingName(), 
                                                                            values.get(i).getAptNumber(), 
                                                                            a.getRooms(), 
                                                                            a.getRent());
        }
    }
    
    public void viewTotalRent(){
        double total = 0;
        System.out.printf("%-10s\t%-30s\t%-10s\n", "Building", "Address", "Total Rent");
         for(int i=0; i<buildings.size(); i++){
                Building b = buildings.get(i);
                double rent = b.getTotalRent();
                System.out.printf("%-10s\t%-30s\t%-10.2f\n", b.getName(), b.getAddress(), rent);
                total += rent;
        }
       System.out.printf("%-40s\t%-10.2f\n", "Total", total);
    }
}